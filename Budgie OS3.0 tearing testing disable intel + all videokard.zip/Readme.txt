Griggorii budgie tearing off

1) inpack as administator arhive ( .drirc ) in /home/ [user_name]  replace

2) Variant  && sudo gedit /home/    -------->[user_name]<-------    /.drirc 

----------------------------------------------------------------------------------------------------------------------------------------------------

<device screen="0" driver="dri2">
        <application name="Default">
                <option name="vblank_mode" value="1"/>
        </application>
</device>
---------------------------------------------------------------------------------------------------------------------------------------------------
Test tering https://www.youtube.com/watch?v=0RvIbVmCOxg
Hidden .drirc 
